import React from 'react';
import Calculator from './Calculator';

export function App(props) {
  return (   <Calculator />);
    // <div className='App'>
    
   
    
    //   <h2>Start editing to see some magic happen!</h2>
    // </div>
 
}

// Log to console
console.log('Hello console');
